create view resident_info as
  select `chilin_eldser_pcw`.`pcw_residents`.`RESIDENTS_ID`      AS `RESIDENT_ID`,
         `chilin_eldser_pcw`.`pcw_residents`.`CHINSES_NAME`      AS `CHINSES_NAME`,
         `chilin_eldser_pcw`.`pcw_residents`.`ENGLISH_NAME`      AS `ENGLISH_NAME`,
         `chilin_eldser_pcw`.`pcw_residents`.`RESIDENTS_NUMBER`  AS `RESIDENTS_NUMBER`,
         `chilin_eldser_pcw`.`pcw_residents`.`RESIDENTS_PICTURE` AS `RESIDENTS_PICTURE`,
         `chilin_eldser_pcw`.`pcw_residents`.`ID_NUMBERS`        AS `ID_NUMBERS`,
         `chilin_eldser_pcw`.`pcw_residents`.`BIRTH_DATE`        AS `BIRTH_DATE`,
         `chilin_eldser_pcw`.`pcw_residents`.`RESIDENTS_SEX`     AS `RESIDENTS_SEX`,
         `chilin_eldser_pcw`.`pcw_residents`.`STATUS`            AS `STATUS`
  from `chilin_eldser_pcw`.`pcw_residents`;

