create view room_info as
  select `chilin_eldser_pcw`.`pcw_room`.`ROOM_ID`     AS `ROOM_ID`,
         `chilin_eldser_pcw`.`pcw_room`.`GROUP_ID`    AS `GROUP_ID`,
         `chilin_eldser_pcw`.`pcw_room`.`ROOM_NAME`   AS `ROOM_NAME`,
         `chilin_eldser_pcw`.`pcw_room`.`ROOM_STOREY` AS `ROOM_STOREY`
  from `chilin_eldser_pcw`.`pcw_room`;

