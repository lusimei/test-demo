create function get_patrol_record_status(recordTime datetime)
  returns int
  comment '获取指定巡房时间的有效性状态'
  BEGIN
    DECLARE START_TIME DATETIME DEFAULT DATE_SUB(NOW(), INTERVAL 30 MINUTE);
    
    IF recordTime>START_TIME THEN
		# 在有效时间内，显示绿色勾
		RETURN 1;
    ELSE
		# 不在有效时间内, 无绿色勾
		RETURN 0;
    END IF;
END;

