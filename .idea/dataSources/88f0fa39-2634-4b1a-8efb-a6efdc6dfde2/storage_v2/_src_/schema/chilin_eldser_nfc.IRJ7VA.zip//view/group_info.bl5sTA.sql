create view group_info as
  select `chilin_eldser_pcw`.`pcw_group`.`GROUP_ID`   AS `GROUP_ID`,
         `chilin_eldser_pcw`.`pcw_group`.`GROUP_NAME` AS `GROUP_NAME`
  from `chilin_eldser_pcw`.`pcw_group`
  where (`chilin_eldser_pcw`.`pcw_group`.`GROUP_ID` <> 7);

