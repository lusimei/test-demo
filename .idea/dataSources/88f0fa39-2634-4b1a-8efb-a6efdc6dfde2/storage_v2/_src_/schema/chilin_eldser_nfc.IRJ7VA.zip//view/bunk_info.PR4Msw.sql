create view bunk_info as
  select `chilin_eldser_pcw`.`pcw_bunk`.`BUNK_ID`      AS `BUNK_ID`,
         `chilin_eldser_pcw`.`pcw_bunk`.`ROOM_ID`      AS `ROOM_ID`,
         `chilin_eldser_pcw`.`pcw_bunk`.`RESIDENTS_ID` AS `RESIDENT_ID`,
         `chilin_eldser_pcw`.`pcw_bunk`.`BUNK_NUMBER`  AS `BUNK_NUMBER`
  from `chilin_eldser_pcw`.`pcw_bunk`
  where (`chilin_eldser_pcw`.`pcw_bunk`.`BUNK_STATUS` = 1);

