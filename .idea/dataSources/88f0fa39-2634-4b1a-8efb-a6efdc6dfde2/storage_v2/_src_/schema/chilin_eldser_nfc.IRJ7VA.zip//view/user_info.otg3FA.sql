create view user_info as
  select `a`.`ACCOUNT_ID`          AS `ACCOUNT_ID`,
         `a`.`ACCOUNT_NAME`        AS `ACCOUNT_NAME`,
         `a`.`ACCOUNT_PASSWORD`    AS `ACCOUNT_PASSWORD`,
         `a`.`ACCOUNT_TYPE`        AS `ACCOUNT_TYPE`,
         `a`.`ACCOUNT_STATUS`      AS `ACCOUNT_STATUS`,
         `c`.`GROUP_ID`            AS `GROUP_ID`,
         `c`.`CLERK_ID`            AS `CLERK_ID`,
         `c`.`CLERK_NAME`          AS `CLERK_NAME`,
         `c`.`CLERK_NUMBER`        AS `CLERK_NUMBER`,
         `c`.`CLERK_PHOTO`         AS `CLERK_PHOTO`,
         `c`.`CLERK_STATUS`        AS `CLERK_STATUS`,
         `c`.`CLERK_SEX`           AS `CLERK_SEX`,
         `c`.`CLERK_DEPARTMENT_ID` AS `CLERK_DEPARTMENT_ID`,
         `c`.`DEPARTMENT`          AS `DEPARTMENT`,
         `c`.`JOB_TITLE`           AS `JOB_TITLE`,
         `r`.`CR_NAME`             AS `CR_NAME`
  from ((`chilin_eldser_pcw`.`pcw_accounts` `a` join `chilin_eldser_pcw`.`pcw_clerk` `c` on ((`c`.`CLERK_ID` =
                                                                                              `a`.`INFO_ID`))) left join (select `chilin_eldser_pcw`.`chilin_role`.`CR_ID`     AS `CR_ID`,
                                                                                                                                 `chilin_eldser_pcw`.`chilin_role`.`CR_NAME`   AS `CR_NAME`,
                                                                                                                                 `chilin_eldser_pcw`.`chilin_role`.`CR_STATUS` AS `CR_STATUS`,
                                                                                                                                 `chilin_eldser_pcw`.`chilin_role`.`CR_REMARK` AS `CR_REMARK`
                                                                                                                          from `chilin_eldser_pcw`.`chilin_role`
                                                                                                                          where (`chilin_eldser_pcw`.`chilin_role`.`CR_STATUS` = 1)) `r` on ((
    `r`.`CR_ID` = `a`.`ACCOUNT_TYPE`)))
  where ((`c`.`CLERK_STATUS` = 1) and (`a`.`ACCOUNT_STATUS` = 1));

